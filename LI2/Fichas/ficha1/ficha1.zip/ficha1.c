#include "ficha1.h"
#include <stdio.h>

void swap (letraValor *x,letraValor *y) {
    letraValor temp;

    temp = *x;
    *x = * y;
    *y = temp;
}

void ordenarAlfabetico (letraValor v[],int N) {

    for (int j = 0; j < N - 1; j++) {
        for (int i = 0; i < N - j - 1; i++) {
            if (v[i].letra > v[i+1].letra) 
                swap (&v[i],&v[i+1]); 
        }
        
    }
}

int leValores (letraValor v[],int N) {

    for (int i = 0; i < N; i++) {
        if (scanf (" %c %lld",&v[i].letra,&v[i].valor) != 2 || !(v[i].valor > 0 && v[i].valor <= 1000000000)) {
            return -1;
        }
    }
    return 0;
}

void contaMultiplos (letraValor v[],int N,long long I,long long F) {

    for (int j = 0; j < N; j++) {
        if (I > F) {
            v[j].valor = 0;
        } else {
            v[j].valor = (F / v[j].valor) - ((I - 1) / v[j].valor);
        }
        
    }

}


